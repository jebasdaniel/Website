import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Plus, Pencil, Trash2 } from "lucide-react";

export const Route = createFileRoute("/dashboard/addresses")({
  component: AddressesPage,
});

const addresses = [
  { id: "1", name: "Home", line: "123 MG Road, Bengaluru, Karnataka 560001", phone: "+91 98765 43210", default: true },
  { id: "2", name: "Office", line: "Tower B, Whitefield, Bengaluru, Karnataka 560066", phone: "+91 98765 43210" },
];

function AddressesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Addresses</h1>
          <p className="text-sm text-muted-foreground">Saved delivery locations</p>
        </div>
        <button className="px-4 py-2 rounded-xl bg-gradient-primary text-primary-foreground text-sm font-semibold shadow-glow flex items-center gap-1.5">
          <Plus className="h-4 w-4" /> Add new
        </button>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {addresses.map((a) => (
          <div key={a.id} className="glass rounded-2xl p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="font-semibold">{a.name}</span>
                {a.default && <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-success/15 text-success">Default</span>}
              </div>
              <div className="flex gap-1">
                <button className="h-8 w-8 rounded-lg hover:bg-secondary/60 flex items-center justify-center text-muted-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                <button className="h-8 w-8 rounded-lg hover:bg-destructive/10 flex items-center justify-center text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-3">{a.line}</p>
            <p className="text-sm text-muted-foreground mt-1">{a.phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Lock, Smartphone, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — JD Gadgets" },
      { name: "description", content: "Sign in to your JD Gadgets account to track orders, manage addresses and shop faster." },
      { property: "og:title", content: "Sign in — JD Gadgets" },
      { property: "og:description", content: "Access your JD Gadgets account." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"email" | "otp">("email");

  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-16 bg-gradient-hero">
      <div className="absolute inset-0 bg-gradient-glow opacity-60 pointer-events-none" />
      <div className="relative w-full max-w-md">
        <div className="glass-strong rounded-3xl p-8 shadow-elegant animate-fade-up">
          <div className="text-center mb-8">
            <div className="mx-auto h-12 w-12 rounded-2xl bg-gradient-primary shadow-glow flex items-center justify-center font-display font-bold text-primary-foreground mb-4">JD</div>
            <h1 className="text-2xl font-bold">Welcome back</h1>
            <p className="text-sm text-muted-foreground mt-1">Sign in to continue shopping</p>
          </div>

          <div className="flex gap-2 p-1 rounded-xl bg-secondary/40 mb-6">
            <button onClick={() => setMode("email")} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-smooth ${mode === "email" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground"}`}>Email</button>
            <button onClick={() => setMode("otp")} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-smooth ${mode === "otp" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground"}`}>Mobile OTP</button>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); navigate({ to: "/dashboard" }); }} className="space-y-4">
            {mode === "email" ? (
              <>
                <Field icon={<Mail className="h-4 w-4" />} type="email" placeholder="you@example.com" label="Email" />
                <Field icon={<Lock className="h-4 w-4" />} type="password" placeholder="••••••••" label="Password" />
                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 text-muted-foreground"><input type="checkbox" className="accent-primary" /> Remember me</label>
                  <Link to="/forgot-password" className="text-primary hover:underline">Forgot password?</Link>
                </div>
              </>
            ) : (
              <>
                <Field icon={<Smartphone className="h-4 w-4" />} type="tel" placeholder="+91 98765 43210" label="Mobile number" />
                <Field icon={<Lock className="h-4 w-4" />} type="text" placeholder="6-digit OTP" label="OTP" />
              </>
            )}

            <button type="submit" className="w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth flex items-center justify-center gap-2">
              Sign in <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" />
          </div>

          <button className="w-full py-3 rounded-xl glass border border-border hover:bg-secondary/40 transition-smooth flex items-center justify-center gap-3 text-sm font-medium">
            <GoogleIcon /> Continue with Google
          </button>

          <p className="text-center text-sm text-muted-foreground mt-6">
            New to JD Gadgets? <Link to="/signup" className="text-primary font-semibold hover:underline">Create account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export function Field({ icon, label, ...props }: { icon: React.ReactNode; label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1.5 relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</span>
        <input
          {...props}
          className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-secondary/40 border border-border/60 focus:border-primary focus:ring-2 focus:ring-ring outline-none text-sm transition-smooth"
        />
      </div>
    </label>
  );
}

export function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.7 3.3 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12s4.3 9.6 9.6 9.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z"/></svg>
  );
}

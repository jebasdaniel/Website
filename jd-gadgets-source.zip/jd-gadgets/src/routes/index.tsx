import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Truck, ShieldCheck, Headphones, RefreshCw, Zap, Star } from "lucide-react";
import heroImg from "@/assets/hero-gadgets.jpg";
import { categories, products } from "@/data/products";
import { ProductCard } from "@/components/ProductCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JD Gadgets — Premium Electronics, Delivered" },
      { name: "description", content: "Latest mobiles, laptops, desktops, tablets & iPads. Apple, Samsung, iQOO, OnePlus and more — at JD Gadgets." },
      { property: "og:title", content: "JD Gadgets — Premium Electronics, Delivered" },
      { property: "og:description", content: "Latest gadgets from the best brands. Fast delivery. Easy returns." },
    ],
  }),
  component: HomePage,
});

const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");

function HomePage() {
  const featured = products.filter(p => p.badge).slice(0, 8);
  const flashDeals = products.filter(p => p.badge === "Deal" || p.badge === "Hot").slice(0, 4);
  const newArrivals = products.filter(p => p.badge === "New").slice(0, 4);

  return (
    <div className="overflow-hidden">
      {/* HERO */}
      <section className="relative">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative mx-auto max-w-7xl px-4 lg:px-8 pt-12 pb-20 lg:pt-20 lg:pb-32 grid lg:grid-cols-2 gap-10 items-center">
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-medium text-primary mb-6">
              <Zap className="h-3.5 w-3.5" />
              New season — up to 40% off flagships
            </div>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
              The future,{" "}
              <span className="gradient-text">in your hands.</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl">
              Premium mobiles, laptops, desktops, tablets and iPads — curated from the world's best brands and delivered to your door.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/shop/$category"
                params={{ category: "mobiles" }}
                className="inline-flex items-center gap-2 h-12 px-6 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:scale-105 transition-smooth"
              >
                Shop now <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/shop/$category"
                params={{ category: "laptops" }}
                className="inline-flex items-center gap-2 h-12 px-6 rounded-xl glass-strong font-semibold hover:bg-secondary/80 transition-smooth"
              >
                Explore laptops
              </Link>
            </div>
            <div className="mt-10 flex items-center gap-8 text-sm text-muted-foreground">
              <div><span className="text-foreground font-bold text-2xl">100+</span><br/>Products</div>
              <div className="h-10 w-px bg-border" />
              <div><span className="text-foreground font-bold text-2xl">15+</span><br/>Brands</div>
              <div className="h-10 w-px bg-border" />
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-warning text-warning" />
                <span className="text-foreground font-bold text-2xl">4.8</span>
                <span className="ml-1">/ Trusted</span>
              </div>
            </div>
          </div>
          <div className="relative animate-fade-up">
            <div className="absolute -inset-10 bg-gradient-glow blur-3xl" />
            <div className="relative rounded-3xl overflow-hidden glass-strong shadow-elegant animate-float">
              <img src={heroImg} alt="Premium gadgets" width={1920} height={1080} className="w-full h-auto" />
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BADGES */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 -mt-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 glass-strong rounded-2xl p-5 shadow-elegant">
          {[
            { icon: ShieldCheck, title: "Secure Payment", desc: "256-bit SSL" },
            { icon: Truck, title: "Free Delivery", desc: "Orders over ₹999" },
            { icon: RefreshCw, title: "Easy Returns", desc: "7-day policy" },
            { icon: Headphones, title: "24/7 Support", desc: "Always here" },
          ].map((b) => (
            <div key={b.title} className="flex items-center gap-3 p-2">
              <div className="h-10 w-10 rounded-lg bg-gradient-primary/20 border border-primary/30 flex items-center justify-center text-primary">
                <b.icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-sm font-semibold">{b.title}</div>
                <div className="text-xs text-muted-foreground">{b.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold">Shop by category</h2>
            <p className="text-muted-foreground mt-2">Find what fits your life.</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.map((c) => (
            <Link
              key={c.id}
              to="/shop/$category"
              params={{ category: c.id }}
              className="group relative aspect-[4/5] rounded-2xl overflow-hidden border border-border/60 card-hover bg-gradient-card"
            >
              <img src={c.image} alt={c.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4">
                <div className="text-xs text-primary font-semibold mb-1">{c.count} products</div>
                <div className="font-display text-xl font-bold">{c.name}</div>
                <div className="mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground group-hover:text-primary transition-smooth">
                  Shop <ArrowRight className="h-3 w-3" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* FLASH DEALS */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-20">
        <div className="rounded-3xl bg-gradient-accent p-px shadow-glow-accent">
          <div className="rounded-3xl bg-background/95 p-6 lg:p-10">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-accent text-accent-foreground text-xs font-bold uppercase tracking-wider mb-3">
                  <Zap className="h-3 w-3" /> Flash Deals
                </div>
                <h2 className="font-display text-3xl sm:text-4xl font-bold">Limited time. Unlimited savings.</h2>
              </div>
              <div className="flex gap-2">
                {["02", "14", "37"].map((n, i) => (
                  <div key={i} className="glass rounded-lg px-3 py-2 text-center min-w-14">
                    <div className="font-display text-xl font-bold">{n}</div>
                    <div className="text-[10px] text-muted-foreground uppercase">{["hrs","min","sec"][i]}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {flashDeals.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold">Featured products</h2>
            <p className="text-muted-foreground mt-2">Editor's picks across the catalog.</p>
          </div>
          <Link to="/shop/$category" params={{ category: "mobiles" }} className="hidden sm:inline-flex items-center gap-1 text-sm text-primary font-semibold">
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      {/* NEW ARRIVALS BANNER */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-20">
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 relative rounded-3xl overflow-hidden bg-gradient-card border border-border/60 p-8 lg:p-12 min-h-[280px] flex flex-col justify-between">
            <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-gradient-primary opacity-30 blur-3xl" />
            <div className="relative">
              <div className="text-xs font-bold uppercase tracking-wider text-primary mb-3">Just landed</div>
              <h3 className="font-display text-3xl lg:text-5xl font-bold leading-tight max-w-md">
                Galaxy S24 Ultra. <br/><span className="gradient-text">AI, redefined.</span>
              </h3>
              <p className="text-muted-foreground mt-3 max-w-md">200MP camera, S Pen and Galaxy AI — built for the future.</p>
            </div>
            <Link to="/product/$id" params={{ id: "m6" }} className="relative inline-flex items-center gap-2 self-start mt-6 h-11 px-5 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:scale-105 transition-smooth w-fit">
              Pre-order <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="relative rounded-3xl overflow-hidden bg-gradient-accent p-px shadow-glow-accent">
            <div className="relative h-full rounded-3xl bg-background/95 p-8 flex flex-col justify-between min-h-[280px]">
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-accent mb-3">Apple</div>
                <h3 className="font-display text-2xl lg:text-3xl font-bold leading-tight">
                  iPad Pro M4. <br/>Impossibly thin.
                </h3>
              </div>
              <Link to="/product/$id" params={{ id: "i1" }} className="inline-flex items-center gap-1 text-sm text-primary font-semibold">
                Discover <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* NEW ARRIVALS GRID */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold">New arrivals</h2>
            <p className="text-muted-foreground mt-2">Fresh on the shelves.</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {newArrivals.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 lg:px-8 mt-24">
        <div className="relative rounded-3xl overflow-hidden glass-strong p-10 lg:p-16 text-center">
          <div className="absolute inset-0 bg-gradient-glow opacity-60" />
          <div className="relative">
            <h2 className="font-display text-3xl lg:text-5xl font-bold max-w-2xl mx-auto">
              Upgrade your everyday with <span className="gradient-text">JD Gadgets.</span>
            </h2>
            <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
              Join thousands who shop premium electronics at the best prices.
            </p>
            <Link to="/shop/$category" params={{ category: "mobiles" }} className="mt-8 inline-flex items-center gap-2 h-12 px-7 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:scale-105 transition-smooth">
              Browse catalog <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

// keep formatter exported-typed-clean
void formatINR;

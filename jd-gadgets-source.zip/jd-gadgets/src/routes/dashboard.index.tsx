import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/dashboard/")({
  component: ProfilePage,
});

function ProfilePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Profile</h1>
        <p className="text-sm text-muted-foreground">Manage your personal information</p>
      </div>
      <div className="glass rounded-2xl p-6 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Full name" defaultValue="Aarav Sharma" />
          <Field label="Email" type="email" defaultValue="aarav@example.com" />
          <Field label="Mobile" type="tel" defaultValue="+91 98765 43210" />
          <Field label="Date of birth" type="date" />
        </div>
        <button className="px-5 py-2.5 rounded-xl bg-gradient-primary text-primary-foreground text-sm font-semibold shadow-glow hover:opacity-90 transition-smooth">
          Save changes
        </button>
      </div>
    </div>
  );
}

function Field({ label, ...p }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <input {...p} className="mt-1.5 w-full px-3 py-2.5 rounded-xl bg-secondary/40 border border-border/60 focus:border-primary focus:ring-2 focus:ring-ring outline-none text-sm transition-smooth" />
    </label>
  );
}

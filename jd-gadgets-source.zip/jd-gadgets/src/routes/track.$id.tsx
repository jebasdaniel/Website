import { createFileRoute, Link } from "@tanstack/react-router";
import { Package, CheckCircle2, Truck, Home, MapPin } from "lucide-react";

export const Route = createFileRoute("/track/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Order ${params.id} — JD Gadgets` },
      { name: "description", content: `Track your JD Gadgets order ${params.id} in real time.` },
    ],
  }),
  component: TrackPage,
});

const stages = [
  { key: "placed", label: "Order placed", icon: CheckCircle2, time: "Today, 10:24 AM" },
  { key: "packed", label: "Packed", icon: Package, time: "Today, 2:15 PM" },
  { key: "shipped", label: "Shipped", icon: Truck, time: "Tomorrow, 9:00 AM" },
  { key: "out", label: "Out for delivery", icon: MapPin, time: "Expected in 3 days" },
  { key: "delivered", label: "Delivered", icon: Home, time: "Estimated delivery" },
];

function TrackPage() {
  const { id } = Route.useParams();
  const currentStage = 1;

  return (
    <div className="mx-auto max-w-5xl px-4 lg:px-8 py-10">
      <div className="glass-strong rounded-3xl p-6 sm:p-8 shadow-elegant">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-primary">Order ID</p>
            <h1 className="text-2xl sm:text-3xl font-bold mt-1">{id}</h1>
            <p className="text-sm text-muted-foreground mt-1">Estimated delivery: <span className="text-foreground font-semibold">In 3 days</span></p>
          </div>
          <div className="flex gap-2">
            <Link to="/dashboard" className="px-4 py-2 rounded-xl glass border border-border text-sm font-semibold hover:bg-secondary/40 transition-smooth">Dashboard</Link>
            <Link to="/" className="px-4 py-2 rounded-xl bg-gradient-primary text-primary-foreground text-sm font-semibold shadow-glow">Continue shopping</Link>
          </div>
        </div>

        <div className="relative">
          <div className="absolute left-5 top-5 bottom-5 w-px bg-border" />
          <div className="absolute left-5 top-5 w-px bg-gradient-to-b from-primary to-accent" style={{ height: `${(currentStage / (stages.length - 1)) * 100}%` }} />
          <ol className="space-y-6">
            {stages.map((s, i) => {
              const active = i <= currentStage;
              const Icon = s.icon;
              return (
                <li key={s.key} className="flex items-start gap-4">
                  <div className={`relative z-10 h-10 w-10 rounded-full flex items-center justify-center ${active ? "bg-gradient-primary text-primary-foreground shadow-glow" : "bg-secondary text-muted-foreground"}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 pt-1.5">
                    <h3 className={`font-semibold ${active ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.time}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 gap-4">
          <div className="glass rounded-2xl p-5">
            <h3 className="font-semibold mb-2">Shipping address</h3>
            <p className="text-sm text-muted-foreground">Aarav Sharma<br/>123 MG Road, Bengaluru, Karnataka 560001<br/>+91 98765 43210</p>
          </div>
          <div className="glass rounded-2xl p-5">
            <h3 className="font-semibold mb-2">Need help?</h3>
            <p className="text-sm text-muted-foreground">Our support team is available 24/7. Call <span className="text-primary font-semibold">1800-JD-GADGETS</span> or chat with us.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { CreditCard, Smartphone, Wallet, Building2, ShieldCheck, CheckCircle2 } from "lucide-react";
import { useCart, formatINR } from "@/context/CartContext";
import { Stepper } from "./cart";

export const Route = createFileRoute("/payment")({
  head: () => ({
    meta: [
      { title: "Payment — JD Gadgets" },
      { name: "description", content: "Pay securely with UPI, cards, net banking, or wallets at JD Gadgets." },
    ],
  }),
  component: PaymentPage,
});

type Method = "upi" | "card" | "netbanking" | "wallet";

function PaymentPage() {
  const navigate = useNavigate();
  const { subtotal, clear } = useCart();
  const [method, setMethod] = useState<Method>("upi");
  const [paying, setPaying] = useState(false);
  const [done, setDone] = useState(false);

  const total = subtotal + (subtotal > 50000 ? 0 : 99) + Math.round(subtotal * 0.05);

  const pay = () => {
    setPaying(true);
    setTimeout(() => {
      setDone(true);
      setTimeout(() => {
        clear();
        navigate({ to: "/track/$id", params: { id: "JDG" + Date.now().toString().slice(-8) } });
      }, 1600);
    }, 1500);
  };

  if (done) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4">
        <div className="text-center animate-fade-up">
          <div className="mx-auto h-24 w-24 rounded-full bg-success/20 flex items-center justify-center animate-glow-pulse">
            <CheckCircle2 className="h-14 w-14 text-success" />
          </div>
          <h1 className="text-3xl font-bold mt-6">Payment successful!</h1>
          <p className="text-muted-foreground mt-2">Redirecting to your order...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-10">
      <Stepper step={2} />
      <h1 className="text-3xl font-bold mt-6 mb-6">Choose payment method</h1>

      <div className="grid lg:grid-cols-[1fr_380px] gap-8">
        <div>
          <div className="glass rounded-2xl p-2 grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
            <Tab active={method === "upi"} onClick={() => setMethod("upi")} icon={<Smartphone />} label="UPI" />
            <Tab active={method === "card"} onClick={() => setMethod("card")} icon={<CreditCard />} label="Card" />
            <Tab active={method === "netbanking"} onClick={() => setMethod("netbanking")} icon={<Building2 />} label="Net Banking" />
            <Tab active={method === "wallet"} onClick={() => setMethod("wallet")} icon={<Wallet />} label="Wallet" />
          </div>

          <div className="glass-strong rounded-2xl p-6">
            {method === "upi" && (
              <div className="space-y-4">
                <Field label="UPI ID" placeholder="yourname@okaxis" />
                <p className="text-xs text-muted-foreground">You'll receive a payment request on your UPI app.</p>
              </div>
            )}
            {method === "card" && (
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2"><Field label="Card number" placeholder="1234 5678 9012 3456" /></div>
                <div className="sm:col-span-2"><Field label="Name on card" placeholder="AARAV SHARMA" /></div>
                <Field label="Expiry" placeholder="MM / YY" />
                <Field label="CVV" placeholder="•••" />
              </div>
            )}
            {method === "netbanking" && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {["HDFC", "ICICI", "SBI", "Axis", "Kotak", "Yes Bank"].map((b) => (
                  <button key={b} className="p-3 rounded-xl border border-border/60 hover:border-primary text-sm font-semibold transition-smooth">{b}</button>
                ))}
              </div>
            )}
            {method === "wallet" && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {["Paytm", "PhonePe", "Amazon Pay", "Mobikwik", "Freecharge"].map((b) => (
                  <button key={b} className="p-3 rounded-xl border border-border/60 hover:border-primary text-sm font-semibold transition-smooth">{b}</button>
                ))}
              </div>
            )}
          </div>

          <button onClick={pay} disabled={paying} className="mt-6 w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth disabled:opacity-60">
            {paying ? "Processing payment..." : `Pay ${formatINR(total)}`}
          </button>
          <p className="mt-3 text-xs text-muted-foreground flex items-center gap-1.5 justify-center">
            <ShieldCheck className="h-3.5 w-3.5 text-success" /> 256-bit encrypted • PCI-DSS compliant
          </p>
        </div>

        <aside className="glass rounded-2xl p-6 sticky top-20 h-fit">
          <h2 className="font-bold mb-4">Paying</h2>
          <div className="text-3xl font-bold gradient-text">{formatINR(total)}</div>
          <p className="text-xs text-muted-foreground mt-1">Inclusive of all taxes</p>
          <Link to="/checkout" className="mt-4 block text-center text-sm text-muted-foreground hover:text-foreground">← Back to address</Link>
        </aside>
      </div>
    </div>
  );
}

function Tab({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className={`p-3 rounded-xl flex flex-col items-center gap-1 text-xs font-semibold transition-smooth ${active ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground hover:bg-secondary/60"}`}>
      <span className="[&_svg]:h-5 [&_svg]:w-5">{icon}</span>
      {label}
    </button>
  );
}

function Field({ label, ...p }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <input {...p} className="mt-1.5 w-full px-3 py-2.5 rounded-xl bg-secondary/40 border border-border/60 focus:border-primary focus:ring-2 focus:ring-ring outline-none text-sm transition-smooth" />
    </label>
  );
}

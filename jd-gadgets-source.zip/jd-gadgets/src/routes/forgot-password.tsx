import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail } from "lucide-react";
import { useState } from "react";
import { Field } from "./login";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset password — JD Gadgets" },
      { name: "description", content: "Reset your JD Gadgets account password." },
    ],
  }),
  component: ForgotPage,
});

function ForgotPage() {
  const [sent, setSent] = useState(false);
  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-16 bg-gradient-hero">
      <div className="absolute inset-0 bg-gradient-glow opacity-60 pointer-events-none" />
      <div className="relative w-full max-w-md">
        <div className="glass-strong rounded-3xl p-8 shadow-elegant">
          <h1 className="text-2xl font-bold text-center">Forgot password?</h1>
          <p className="text-sm text-muted-foreground text-center mt-1">We'll send you a reset link</p>

          {sent ? (
            <div className="mt-8 p-4 rounded-xl bg-success/10 border border-success/30 text-success text-sm text-center">
              Check your inbox for the reset link.
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="mt-6 space-y-4">
              <Field icon={<Mail className="h-4 w-4" />} type="email" placeholder="you@example.com" label="Email" />
              <button type="submit" className="w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth">
                Send reset link
              </button>
            </form>
          )}

          <p className="text-center text-sm text-muted-foreground mt-6">
            Remembered? <Link to="/login" className="text-primary font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

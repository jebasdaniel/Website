import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin, Truck, Zap } from "lucide-react";
import { useCart, formatINR } from "@/context/CartContext";
import { Stepper } from "./cart";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — JD Gadgets" },
      { name: "description", content: "Securely complete your JD Gadgets order with saved addresses and fast delivery." },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const navigate = useNavigate();
  const { subtotal, items } = useCart();
  const [delivery, setDelivery] = useState<"standard" | "express">("standard");
  const shipping = delivery === "express" ? 199 : (subtotal > 50000 ? 0 : 99);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + shipping + tax;

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-10">
      <Stepper step={1} />
      <h1 className="text-3xl font-bold mt-6 mb-6">Shipping & Delivery</h1>

      <div className="grid lg:grid-cols-[1fr_380px] gap-8">
        <form onSubmit={(e) => { e.preventDefault(); navigate({ to: "/payment" }); }} className="space-y-6">
          <div className="glass rounded-2xl p-6">
            <h2 className="font-bold flex items-center gap-2 mb-4"><MapPin className="h-4 w-4 text-primary" /> Delivery address</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <Input label="Full name" placeholder="Aarav Sharma" />
              <Input label="Phone" placeholder="+91 98765 43210" />
              <Input label="Pincode" placeholder="560001" />
              <Input label="City" placeholder="Bengaluru" />
              <div className="sm:col-span-2"><Input label="Address" placeholder="Flat / House no., Street, Area" /></div>
              <Input label="State" placeholder="Karnataka" />
              <Input label="Landmark (optional)" placeholder="Near Metro Station" />
            </div>
          </div>

          <div className="glass rounded-2xl p-6">
            <h2 className="font-bold flex items-center gap-2 mb-4"><Truck className="h-4 w-4 text-primary" /> Delivery options</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <DeliveryOpt selected={delivery === "standard"} onClick={() => setDelivery("standard")} title="Standard" eta="3–5 days" price={subtotal > 50000 ? "FREE" : "₹99"} />
              <DeliveryOpt selected={delivery === "express"} onClick={() => setDelivery("express")} title="Express" eta="1–2 days" price="₹199" icon={<Zap className="h-4 w-4 text-warning" />} />
            </div>
          </div>

          <button type="submit" className="w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth">
            Continue to payment
          </button>
        </form>

        <aside className="glass-strong rounded-2xl p-6 sticky top-20 h-fit">
          <h2 className="font-bold mb-4">Summary</h2>
          <div className="space-y-2 text-sm">
            <Row label={`Items (${items.length})`} value={formatINR(subtotal)} />
            <Row label="Shipping" value={shipping === 0 ? "FREE" : formatINR(shipping)} />
            <Row label="GST (5%)" value={formatINR(tax)} />
            <div className="border-t border-border/60 pt-3 flex justify-between font-bold text-lg">
              <span>Total</span><span>{formatINR(total)}</span>
            </div>
          </div>
          <Link to="/cart" className="mt-4 block text-center text-sm text-muted-foreground hover:text-foreground">← Back to cart</Link>
        </aside>
      </div>
    </div>
  );
}

function Input({ label, ...p }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <input {...p} className="mt-1.5 w-full px-3 py-2.5 rounded-xl bg-secondary/40 border border-border/60 focus:border-primary focus:ring-2 focus:ring-ring outline-none text-sm transition-smooth" />
    </label>
  );
}

function DeliveryOpt({ selected, onClick, title, eta, price, icon }: { selected: boolean; onClick: () => void; title: string; eta: string; price: string; icon?: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={`text-left p-4 rounded-xl border transition-smooth ${selected ? "border-primary bg-primary/5 shadow-glow" : "border-border/60 hover:border-border"}`}>
      <div className="flex items-center justify-between">
        <span className="font-semibold flex items-center gap-1.5">{icon}{title}</span>
        <span className="font-bold">{price}</span>
      </div>
      <p className="text-xs text-muted-foreground mt-1">Delivery in {eta}</p>
    </button>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between"><span className="text-muted-foreground">{label}</span><span className="font-medium">{value}</span></div>;
}

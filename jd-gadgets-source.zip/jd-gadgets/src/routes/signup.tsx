import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Mail, Lock, User } from "lucide-react";
import { Field, GoogleIcon } from "./login";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create account — JD Gadgets" },
      { name: "description", content: "Join JD Gadgets for exclusive offers, faster checkout and order tracking." },
      { property: "og:title", content: "Create account — JD Gadgets" },
      { property: "og:description", content: "Join JD Gadgets for exclusive offers." },
    ],
  }),
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  return (
    <div className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-16 bg-gradient-hero">
      <div className="absolute inset-0 bg-gradient-glow opacity-60 pointer-events-none" />
      <div className="relative w-full max-w-md">
        <div className="glass-strong rounded-3xl p-8 shadow-elegant animate-fade-up">
          <div className="text-center mb-8">
            <div className="mx-auto h-12 w-12 rounded-2xl bg-gradient-primary shadow-glow flex items-center justify-center font-display font-bold text-primary-foreground mb-4">JD</div>
            <h1 className="text-2xl font-bold">Create your account</h1>
            <p className="text-sm text-muted-foreground mt-1">Premium electronics, delivered fast</p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); navigate({ to: "/dashboard" }); }} className="space-y-4">
            <Field icon={<User className="h-4 w-4" />} type="text" placeholder="Aarav Sharma" label="Full name" />
            <Field icon={<Mail className="h-4 w-4" />} type="email" placeholder="you@example.com" label="Email" />
            <Field icon={<Lock className="h-4 w-4" />} type="password" placeholder="Min. 8 characters" label="Password" />
            <button type="submit" className="w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth">
              Create account
            </button>
          </form>

          <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" />
          </div>
          <button className="w-full py-3 rounded-xl glass border border-border hover:bg-secondary/40 transition-smooth flex items-center justify-center gap-3 text-sm font-medium">
            <GoogleIcon /> Continue with Google
          </button>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account? <Link to="/login" className="text-primary font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

import { createFileRoute, notFound, Link, useNavigate } from "@tanstack/react-router";
import { Star, Heart, ShoppingCart, Zap, ShieldCheck, Truck, RefreshCw, ChevronRight, Check } from "lucide-react";
import { useState } from "react";
import { getProduct, products } from "@/data/products";
import { ProductCard } from "@/components/ProductCard";
import { useCart } from "@/context/CartContext";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = getProduct(params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData ? [
      { title: `${loaderData.product.name} — JD Gadgets` },
      { name: "description", content: `${loaderData.product.name} by ${loaderData.product.brand}. ${loaderData.product.highlights.join(", ")}.` },
      { property: "og:title", content: `${loaderData.product.name} — JD Gadgets` },
      { property: "og:description", content: `${loaderData.product.name} by ${loaderData.product.brand}.` },
      { property: "og:image", content: loaderData.product.image },
    ] : [],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-7xl px-4 py-20 text-center">
      <h1 className="font-display text-3xl font-bold">Product not found</h1>
      <Link to="/" className="mt-4 inline-block text-primary">Go home</Link>
    </div>
  ),
  component: ProductPage,
});

const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");

function ProductPage() {
  const { product } = Route.useLoaderData();
  const [qty, setQty] = useState(1);
  const { add } = useCart();
  const navigate = useNavigate();
  const off = Math.round(((product.mrp - product.price) / product.mrp) * 100);
  const emi = Math.round(product.price / 12);

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-4">
        <Link to="/" className="hover:text-foreground">Home</Link>
        <ChevronRight className="h-3 w-3" />
        <Link to="/shop/$category" params={{ category: product.category }} className="hover:text-foreground capitalize">{product.category}</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground truncate">{product.name}</span>
      </nav>

      <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square rounded-3xl overflow-hidden glass-strong group">
            <div className="absolute inset-0 bg-gradient-glow opacity-50" />
            <img src={product.image} alt={product.name} className="relative h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
            {product.badge && (
              <span className="absolute top-4 left-4 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-gradient-accent text-accent-foreground shadow-glow-accent">
                {product.badge}
              </span>
            )}
          </div>
          <div className="grid grid-cols-4 gap-3">
            {[0,1,2,3].map(i => (
              <button key={i} className="aspect-square rounded-xl overflow-hidden border-2 border-border hover:border-primary transition-smooth bg-background">
                <img src={product.image} alt="" className="h-full w-full object-cover opacity-80" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-primary mb-2">{product.brand}</div>
          <h1 className="font-display text-3xl lg:text-4xl font-bold leading-tight">{product.name}</h1>

          <div className="mt-3 flex items-center gap-3">
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-success/15 text-success text-sm font-semibold">
              <Star className="h-3.5 w-3.5 fill-current" />
              {product.rating}
            </div>
            <span className="text-sm text-muted-foreground">{product.reviews.toLocaleString("en-IN")} reviews</span>
          </div>

          <div className="mt-6 p-5 rounded-2xl glass-strong">
            <div className="flex items-baseline gap-3 flex-wrap">
              <span className="text-4xl font-bold">{formatINR(product.price)}</span>
              <span className="text-lg text-muted-foreground line-through">{formatINR(product.mrp)}</span>
              {off > 0 && <span className="text-sm font-bold text-success">{off}% off</span>}
            </div>
            <div className="mt-2 text-sm text-muted-foreground">
              or <span className="text-foreground font-semibold">{formatINR(emi)}/mo</span> with No-Cost EMI
            </div>
          </div>

          <div className="mt-6 space-y-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Highlights</h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {product.highlights.map(h => (
                <li key={h} className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-primary flex-shrink-0" />
                  {h}
                </li>
              ))}
              {product.storage && (
                <li className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-primary flex-shrink-0" /> {product.storage} storage
                </li>
              )}
              {product.ram && (
                <li className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-primary flex-shrink-0" /> {product.ram} RAM
                </li>
              )}
            </ul>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <span className="text-sm text-muted-foreground">Qty</span>
            <div className="flex items-center rounded-lg border border-border overflow-hidden">
              <button onClick={() => setQty(q => Math.max(1, q-1))} className="h-10 w-10 hover:bg-secondary">−</button>
              <span className="w-10 text-center font-semibold">{qty}</span>
              <button onClick={() => setQty(q => q+1)} className="h-10 w-10 hover:bg-secondary">+</button>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button onClick={() => add(product, qty)} className="flex-1 min-w-[160px] inline-flex items-center justify-center gap-2 h-12 px-6 rounded-xl glass-strong font-semibold hover:bg-secondary/80 transition-smooth">
              <ShoppingCart className="h-5 w-5" /> Add to cart
            </button>
            <button onClick={() => { add(product, qty); navigate({ to: "/checkout" }); }} className="flex-1 min-w-[160px] inline-flex items-center justify-center gap-2 h-12 px-6 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:scale-105 transition-smooth">
              <Zap className="h-5 w-5" /> Buy now
            </button>
            <button aria-label="Wishlist" className="h-12 w-12 inline-flex items-center justify-center rounded-xl border border-border hover:bg-secondary transition-smooth">
              <Heart className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-3">
            {[
              { icon: Truck, label: "Free delivery" },
              { icon: ShieldCheck, label: "1Y warranty" },
              { icon: RefreshCw, label: "7-day returns" },
            ].map(b => (
              <div key={b.label} className="flex flex-col items-center text-center gap-2 p-3 rounded-xl glass">
                <b.icon className="h-5 w-5 text-primary" />
                <span className="text-xs">{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Specs */}
      <section className="mt-16">
        <h2 className="font-display text-2xl font-bold mb-4">Specifications</h2>
        <div className="rounded-2xl glass-strong overflow-hidden">
          <dl className="divide-y divide-border">
            {[
              ["Brand", product.brand],
              ["Model", product.name],
              ["Category", product.category.charAt(0).toUpperCase() + product.category.slice(1)],
              ...(product.storage ? [["Storage", product.storage]] : []),
              ...(product.ram ? [["RAM / Memory", product.ram]] : []),
              ["Highlights", product.highlights.join(", ")],
              ["Rating", `${product.rating} / 5 (${product.reviews.toLocaleString("en-IN")} reviews)`],
            ].map(([k, v]) => (
              <div key={k} className="grid grid-cols-3 px-5 py-3 text-sm">
                <dt className="text-muted-foreground">{k}</dt>
                <dd className="col-span-2 font-medium">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Reviews */}
      <section className="mt-16">
        <h2 className="font-display text-2xl font-bold mb-4">Reviews & Ratings</h2>
        <div className="grid md:grid-cols-[260px_1fr] gap-6">
          <div className="rounded-2xl glass-strong p-6 text-center">
            <div className="text-5xl font-bold gradient-text">{product.rating}</div>
            <div className="flex justify-center gap-0.5 mt-2">
              {[1,2,3,4,5].map(i => (
                <Star key={i} className={`h-4 w-4 ${i <= Math.round(product.rating) ? "fill-warning text-warning" : "text-muted"}`} />
              ))}
            </div>
            <div className="text-xs text-muted-foreground mt-2">{product.reviews.toLocaleString("en-IN")} reviews</div>
          </div>
          <div className="space-y-3">
            {[
              { name: "Aarav S.", rating: 5, text: "Absolutely premium experience. Camera is incredible and battery easily lasts a day." },
              { name: "Priya K.", rating: 5, text: "Build quality is top-notch. Worth every rupee. Delivery was super fast too." },
              { name: "Rohan M.", rating: 4, text: "Great device overall. Performance is silky smooth, only minor heating during gaming." },
            ].map((r, i) => (
              <div key={i} className="rounded-2xl glass p-5">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{r.name}</div>
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map(s => (
                      <Star key={s} className={`h-3.5 w-3.5 ${s <= r.rating ? "fill-warning text-warning" : "text-muted"}`} />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-2">{r.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="font-display text-2xl font-bold mb-4">You may also like</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}

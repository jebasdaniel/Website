import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { User, MapPin, Package, Heart, LogOut } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "My Account — JD Gadgets" },
      { name: "description", content: "Manage your JD Gadgets profile, orders, addresses and wishlist." },
    ],
  }),
  component: DashboardLayout,
});

function DashboardLayout() {
  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-10">
      <div className="grid lg:grid-cols-[260px_1fr] gap-8">
        <aside className="glass-strong rounded-2xl p-4 h-fit lg:sticky lg:top-20">
          <div className="px-3 py-4 border-b border-border/60">
            <div className="h-12 w-12 rounded-full bg-gradient-primary shadow-glow flex items-center justify-center font-bold text-primary-foreground">A</div>
            <p className="mt-3 font-semibold">Aarav Sharma</p>
            <p className="text-xs text-muted-foreground">aarav@example.com</p>
          </div>
          <nav className="mt-3 space-y-1">
            <NavItem to="/dashboard" icon={<User />} label="Profile" exact />
            <NavItem to="/dashboard/orders" icon={<Package />} label="Orders" />
            <NavItem to="/dashboard/addresses" icon={<MapPin />} label="Addresses" />
            <NavItem to="/dashboard/wishlist" icon={<Heart />} label="Wishlist" />
            <Link to="/login" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-smooth">
              <LogOut className="h-4 w-4" /> Sign out
            </Link>
          </nav>
        </aside>
        <div>
          <Outlet />
        </div>
      </div>
    </div>
  );
}

function NavItem({ to, icon, label, exact }: { to: string; icon: React.ReactNode; label: string; exact?: boolean }) {
  return (
    <Link
      to={to}
      activeOptions={{ exact }}
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:bg-secondary/60 hover:text-foreground transition-smooth [&_svg]:h-4 [&_svg]:w-4"
      activeProps={{ className: "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-semibold bg-gradient-primary/15 text-foreground border border-primary/30 [&_svg]:h-4 [&_svg]:w-4 [&_svg]:text-primary" }}
    >
      {icon} {label}
    </Link>
  );
}

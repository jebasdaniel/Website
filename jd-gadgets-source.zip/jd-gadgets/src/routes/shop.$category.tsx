import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Grid3x3, List, ChevronRight } from "lucide-react";
import { ProductCard } from "@/components/ProductCard";
import { categories, getByCategory, type Category } from "@/data/products";

const VALID: Category[] = ["mobiles", "laptops", "desktops", "tablets", "ipads"];

export const Route = createFileRoute("/shop/$category")({
  loader: ({ params }) => {
    if (!VALID.includes(params.category as Category)) throw notFound();
    const cat = params.category as Category;
    const meta = categories.find(c => c.id === cat)!;
    return { category: cat, meta };
  },
  head: ({ loaderData }) => ({
    meta: loaderData ? [
      { title: `${loaderData.meta.name} — JD Gadgets` },
      { name: "description", content: `Shop premium ${loaderData.meta.name.toLowerCase()} from top brands at JD Gadgets.` },
      { property: "og:title", content: `${loaderData.meta.name} — JD Gadgets` },
      { property: "og:description", content: `Shop premium ${loaderData.meta.name.toLowerCase()} from top brands.` },
    ] : [],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-20 text-center">
      <h1 className="font-display text-3xl font-bold">Category not found</h1>
      <Link to="/" className="mt-4 inline-block text-primary">Go home</Link>
    </div>
  ),
  component: ShopCategory,
});

const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");

function ShopCategory() {
  const { category, meta } = Route.useLoaderData();
  const all = useMemo(() => getByCategory(category), [category]);
  const brandsAvail = useMemo(() => Array.from(new Set(all.map(p => p.brand))).sort(), [all]);

  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(Math.max(...all.map(p => p.price)));
  const [minRating, setMinRating] = useState<number>(0);
  const [sort, setSort] = useState<"popular" | "price-asc" | "price-desc" | "newest">("popular");
  const [view, setView] = useState<"grid" | "list">("grid");

  const filtered = useMemo(() => {
    let list = all.filter(p =>
      (selectedBrands.length === 0 || selectedBrands.includes(p.brand)) &&
      p.price <= maxPrice &&
      p.rating >= minRating
    );
    switch (sort) {
      case "price-asc": list = [...list].sort((a, b) => a.price - b.price); break;
      case "price-desc": list = [...list].sort((a, b) => b.price - a.price); break;
      case "newest": list = [...list].sort((a, b) => (b.badge === "New" ? 1 : 0) - (a.badge === "New" ? 1 : 0)); break;
      default: list = [...list].sort((a, b) => b.reviews - a.reviews);
    }
    return list;
  }, [all, selectedBrands, maxPrice, minRating, sort]);

  const toggleBrand = (b: string) =>
    setSelectedBrands(prev => prev.includes(b) ? prev.filter(x => x !== b) : [...prev, b]);

  const priceCeiling = Math.max(...all.map(p => p.price));

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      {/* breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-4">
        <Link to="/" className="hover:text-foreground">Home</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">{meta.name}</span>
      </nav>

      {/* header */}
      <div className="rounded-2xl glass-strong p-6 mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold">{meta.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">{filtered.length} of {all.length} products</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="h-10 px-3 rounded-lg bg-secondary/60 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="popular">Popularity</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="newest">Newest</option>
          </select>
          <div className="flex rounded-lg border border-border overflow-hidden">
            <button onClick={() => setView("grid")} className={`h-10 w-10 flex items-center justify-center ${view === "grid" ? "bg-secondary" : ""}`} aria-label="Grid"><Grid3x3 className="h-4 w-4" /></button>
            <button onClick={() => setView("list")} className={`h-10 w-10 flex items-center justify-center ${view === "list" ? "bg-secondary" : ""}`} aria-label="List"><List className="h-4 w-4" /></button>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[260px_1fr] gap-6">
        {/* sidebar */}
        <aside className="rounded-2xl glass-strong p-5 space-y-6 h-fit lg:sticky lg:top-20">
          <div>
            <h3 className="text-sm font-semibold mb-3">Brand</h3>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {brandsAvail.map(b => (
                <label key={b} className="flex items-center gap-2 text-sm cursor-pointer text-muted-foreground hover:text-foreground">
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(b)}
                    onChange={() => toggleBrand(b)}
                    className="h-4 w-4 rounded border-border bg-secondary accent-primary"
                  />
                  {b}
                </label>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-3">Max price</h3>
            <input
              type="range"
              min={Math.min(...all.map(p => p.price))}
              max={priceCeiling}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-primary"
            />
            <div className="text-xs text-muted-foreground mt-1">Up to {formatINR(maxPrice)}</div>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-3">Min rating</h3>
            <div className="flex flex-wrap gap-2">
              {[0, 4, 4.5].map(r => (
                <button
                  key={r}
                  onClick={() => setMinRating(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs border transition-smooth ${minRating === r ? "bg-gradient-primary text-primary-foreground border-transparent" : "border-border text-muted-foreground hover:text-foreground"}`}
                >
                  {r === 0 ? "All" : `${r}+ ★`}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => { setSelectedBrands([]); setMaxPrice(priceCeiling); setMinRating(0); }}
            className="w-full h-9 rounded-lg border border-border text-xs font-semibold hover:bg-secondary"
          >
            Clear filters
          </button>
        </aside>

        {/* products */}
        <div>
          {filtered.length === 0 ? (
            <div className="rounded-2xl glass p-12 text-center text-muted-foreground">No products match your filters.</div>
          ) : view === "grid" ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {filtered.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(p => {
                const off = Math.round(((p.mrp - p.price) / p.mrp) * 100);
                return (
                  <Link
                    key={p.id}
                    to="/product/$id"
                    params={{ id: p.id }}
                    className="flex gap-4 rounded-2xl bg-gradient-card border border-border/60 p-4 card-hover"
                  >
                    <div className="h-28 w-28 sm:h-32 sm:w-32 rounded-xl overflow-hidden bg-background flex-shrink-0">
                      <img src={p.image} alt={p.name} loading="lazy" className="h-full w-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-semibold uppercase tracking-wider text-primary">{p.brand}</div>
                      <div className="font-semibold truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-1">{p.highlights.join(" • ")}</div>
                      <div className="mt-3 flex items-baseline gap-2">
                        <span className="text-lg font-bold">{formatINR(p.price)}</span>
                        <span className="text-xs text-muted-foreground line-through">{formatINR(p.mrp)}</span>
                        {off > 0 && <span className="text-xs font-semibold text-success">{off}% off</span>}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

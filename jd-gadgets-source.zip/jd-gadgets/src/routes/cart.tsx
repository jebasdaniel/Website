import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2, ShoppingBag, Tag, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { useCart, formatINR } from "@/context/CartContext";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — JD Gadgets" },
      { name: "description", content: "Review your selected gadgets and proceed to secure checkout at JD Gadgets." },
      { property: "og:title", content: "Your Cart — JD Gadgets" },
      { property: "og:description", content: "Review your gadgets and check out securely." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, subtotal } = useCart();
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<number>(0);

  const shipping = subtotal > 0 && subtotal < 50000 ? 99 : 0;
  const tax = Math.round(subtotal * 0.05);
  const total = Math.max(0, subtotal + shipping + tax - applied);

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 lg:px-8 py-24 text-center">
        <div className="mx-auto h-20 w-20 rounded-3xl bg-gradient-primary/20 flex items-center justify-center mb-6">
          <ShoppingBag className="h-10 w-10 text-primary" />
        </div>
        <h1 className="text-3xl font-bold">Your cart is empty</h1>
        <p className="text-muted-foreground mt-2">Discover premium gadgets from top brands.</p>
        <Link to="/" className="mt-6 inline-flex px-6 py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth">
          Continue shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 py-10">
      <Stepper step={0} />
      <h1 className="text-3xl font-bold mt-6 mb-6">Your cart <span className="text-muted-foreground text-lg font-normal">({items.length} items)</span></h1>

      <div className="grid lg:grid-cols-[1fr_380px] gap-8">
        <div className="space-y-4">
          {items.map(({ product, qty }) => (
            <div key={product.id} className="glass rounded-2xl p-4 flex gap-4">
              <Link to="/product/$id" params={{ id: product.id }} className="h-28 w-28 rounded-xl overflow-hidden bg-background flex-shrink-0">
                <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
              </Link>
              <div className="flex-1 min-w-0">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-primary">{product.brand}</span>
                <Link to="/product/$id" params={{ id: product.id }} className="block font-semibold leading-snug line-clamp-2 hover:text-primary transition-smooth">{product.name}</Link>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-lg font-bold">{formatINR(product.price)}</span>
                  <span className="text-xs text-muted-foreground line-through">{formatINR(product.mrp)}</span>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center gap-1 rounded-lg border border-border/60 p-1">
                    <button onClick={() => setQty(product.id, qty - 1)} className="h-7 w-7 rounded-md hover:bg-secondary/60 flex items-center justify-center"><Minus className="h-3 w-3" /></button>
                    <span className="w-8 text-center text-sm font-semibold">{qty}</span>
                    <button onClick={() => setQty(product.id, qty + 1)} className="h-7 w-7 rounded-md hover:bg-secondary/60 flex items-center justify-center"><Plus className="h-3 w-3" /></button>
                  </div>
                  <button onClick={() => remove(product.id)} className="text-xs text-muted-foreground hover:text-destructive flex items-center gap-1 transition-smooth">
                    <Trash2 className="h-3.5 w-3.5" /> Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <aside className="space-y-4">
          <div className="glass-strong rounded-2xl p-6 sticky top-20">
            <h2 className="font-bold mb-4">Order summary</h2>
            <div className="flex gap-2 mb-4">
              <div className="relative flex-1">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Coupon code" className="w-full pl-9 pr-3 py-2 rounded-lg bg-secondary/40 border border-border/60 text-sm outline-none focus:border-primary" />
              </div>
              <button onClick={() => setApplied(coupon.toUpperCase() === "JD500" ? 500 : 0)} className="px-3 py-2 rounded-lg bg-secondary text-sm font-semibold hover:bg-secondary/70 transition-smooth">Apply</button>
            </div>

            <dl className="space-y-2 text-sm border-t border-border/60 pt-4">
              <Row label="Subtotal" value={formatINR(subtotal)} />
              <Row label="Shipping" value={shipping === 0 ? "FREE" : formatINR(shipping)} />
              <Row label="GST (5%)" value={formatINR(tax)} />
              {applied > 0 && <Row label="Coupon" value={"− " + formatINR(applied)} accent />}
              <div className="border-t border-border/60 pt-3 flex justify-between font-bold text-lg">
                <span>Total</span><span>{formatINR(total)}</span>
              </div>
            </dl>

            <Link to="/checkout" className="mt-6 block text-center w-full py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-glow hover:opacity-90 transition-smooth">
              Proceed to checkout
            </Link>
            <p className="mt-3 text-xs text-muted-foreground flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5 text-success" /> 100% secure payment</p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Row({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex justify-between">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className={accent ? "text-success font-semibold" : "font-medium"}>{value}</dd>
    </div>
  );
}

export function Stepper({ step }: { step: 0 | 1 | 2 | 3 }) {
  const steps = ["Cart", "Address", "Payment", "Done"];
  return (
    <ol className="flex items-center gap-2 text-xs sm:text-sm">
      {steps.map((s, i) => (
        <li key={s} className="flex items-center gap-2 flex-1">
          <span className={`h-7 w-7 rounded-full flex items-center justify-center font-bold text-xs ${i <= step ? "bg-gradient-primary text-primary-foreground shadow-glow" : "bg-secondary text-muted-foreground"}`}>{i + 1}</span>
          <span className={i <= step ? "font-semibold" : "text-muted-foreground"}>{s}</span>
          {i < steps.length - 1 && <span className={`flex-1 h-px ${i < step ? "bg-primary" : "bg-border"}`} />}
        </li>
      ))}
    </ol>
  );
}

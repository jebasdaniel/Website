import { createFileRoute, Link } from "@tanstack/react-router";
import { Package } from "lucide-react";
import { products } from "@/data/products";
import { formatINR } from "@/context/CartContext";

export const Route = createFileRoute("/dashboard/orders")({
  component: OrdersPage,
});

const orders = [
  { id: "JDG48201375", status: "Delivered", date: "Apr 18, 2026", productId: products[0]?.id ?? "" },
  { id: "JDG48155902", status: "Shipped", date: "Apr 22, 2026", productId: products[5]?.id ?? "" },
  { id: "JDG48077431", status: "Processing", date: "Apr 24, 2026", productId: products[12]?.id ?? "" },
];

function OrdersPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Orders</h1>
        <p className="text-sm text-muted-foreground">Track and manage your purchases</p>
      </div>
      <div className="space-y-3">
        {orders.map((o) => {
          const p = products.find((x) => x.id === o.productId);
          if (!p) return null;
          return (
            <div key={o.id} className="glass rounded-2xl p-4 flex flex-wrap items-center gap-4">
              <div className="h-16 w-16 rounded-xl bg-background overflow-hidden flex-shrink-0">
                <img src={p.image} alt={p.name} className="h-full w-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">{o.id} • {o.date}</p>
                <p className="font-semibold line-clamp-1">{p.name}</p>
                <p className="text-sm text-muted-foreground">{formatINR(p.price)}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${o.status === "Delivered" ? "bg-success/15 text-success" : o.status === "Shipped" ? "bg-primary/15 text-primary" : "bg-warning/15 text-warning"}`}>
                {o.status}
              </span>
              <Link to="/track/$id" params={{ id: o.id }} className="px-4 py-2 rounded-xl glass border border-border text-xs font-semibold hover:bg-secondary/40 transition-smooth flex items-center gap-1.5">
                <Package className="h-3.5 w-3.5" /> Track
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import { Link } from "@tanstack/react-router";
import { Star, Heart } from "lucide-react";
import type { Product } from "@/data/products";

const formatINR = (n: number) => "₹" + n.toLocaleString("en-IN");

export function ProductCard({ product }: { product: Product }) {
  const discount = Math.round(((product.mrp - product.price) / product.mrp) * 100);
  return (
    <Link
      to="/product/$id"
      params={{ id: product.id }}
      className="group relative rounded-2xl bg-gradient-card border border-border/60 overflow-hidden card-hover flex flex-col"
    >
      {product.badge && (
        <span className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-gradient-accent text-accent-foreground shadow-glow-accent">
          {product.badge}
        </span>
      )}
      <button
        aria-label="Wishlist"
        onClick={(e) => { e.preventDefault(); }}
        className="absolute top-3 right-3 z-10 h-8 w-8 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-destructive transition-smooth"
      >
        <Heart className="h-4 w-4" />
      </button>

      <div className="relative aspect-square overflow-hidden bg-background">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
      </div>

      <div className="flex-1 p-4 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-primary">{product.brand}</span>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-warning text-warning" />
            {product.rating}
          </span>
        </div>
        <h3 className="text-sm font-semibold leading-snug line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>
        <p className="text-xs text-muted-foreground line-clamp-1">
          {product.highlights.slice(0, 2).join(" • ")}
        </p>
        <div className="mt-auto flex items-baseline gap-2 pt-2">
          <span className="text-lg font-bold">{formatINR(product.price)}</span>
          <span className="text-xs text-muted-foreground line-through">{formatINR(product.mrp)}</span>
          {discount > 0 && (
            <span className="text-xs font-semibold text-success">{discount}% off</span>
          )}
        </div>
      </div>
    </Link>
  );
}

import { Link } from "@tanstack/react-router";
import { Search, ShoppingCart, Heart, User, Menu } from "lucide-react";
import { useState } from "react";
import type { Category } from "@/data/products";
import { useCart } from "@/context/CartContext";

const nav: Array<{ label: string } & ({ home: true } | { cat: Category })> = [
  { label: "Home", home: true },
  { label: "Mobiles", cat: "mobiles" },
  { label: "Laptops", cat: "laptops" },
  { label: "Desktops", cat: "desktops" },
  { label: "Tablets", cat: "tablets" },
  { label: "iPads", cat: "ipads" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="glass-strong border-b border-border/60">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 lg:px-8">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="relative h-9 w-9 rounded-xl bg-gradient-primary shadow-glow flex items-center justify-center font-display font-bold text-primary-foreground">
              JD
            </div>
            <span className="font-display text-xl font-bold tracking-tight hidden sm:inline">
              JD <span className="gradient-text">Gadgets</span>
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {nav.map((n) => "home" in n ? (
              <Link
                key="home"
                to="/"
                className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-smooth rounded-lg hover:bg-secondary/60"
                activeProps={{ className: "px-3 py-2 text-sm font-semibold text-foreground rounded-lg bg-secondary/80" }}
                activeOptions={{ exact: true }}
              >
                {n.label}
              </Link>
            ) : (
              <Link
                key={n.cat}
                to="/shop/$category"
                params={{ category: n.cat }}
                className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-smooth rounded-lg hover:bg-secondary/60"
                activeProps={{ className: "px-3 py-2 text-sm font-semibold text-foreground rounded-lg bg-secondary/80" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-1">
            <button className="hidden md:flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-smooth">
              <Search className="h-4 w-4" />
              <span>Search</span>
            </button>
            <Link to="/dashboard/wishlist" aria-label="Wishlist" className="hidden sm:flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-smooth">
              <Heart className="h-5 w-5" />
            </Link>
            <Link to="/login" aria-label="Account" className="hidden sm:flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-smooth">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/cart" aria-label="Cart" className="relative flex h-10 w-10 items-center justify-center rounded-lg text-foreground hover:bg-secondary/60 transition-smooth">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-gradient-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                {count}
              </span>
            </Link>
            <button
              aria-label="Menu"
              className="lg:hidden h-10 w-10 flex items-center justify-center rounded-lg hover:bg-secondary/60 transition-smooth"
              onClick={() => setOpen((v) => !v)}
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>

        {open && (
          <nav className="lg:hidden border-t border-border/60 px-4 py-3 flex flex-col gap-1">
            {nav.map((n) => "home" in n ? (
              <Link
                key="home"
                to="/"
                onClick={() => setOpen(false)}
                className="px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
              >
                {n.label}
              </Link>
            ) : (
              <Link
                key={n.cat}
                to="/shop/$category"
                params={{ category: n.cat }}
                onClick={() => setOpen(false)}
                className="px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
              >
                {n.label}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}

import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60">
      <div className="mx-auto max-w-7xl px-4 lg:px-8 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-9 w-9 rounded-xl bg-gradient-primary shadow-glow flex items-center justify-center font-display font-bold text-primary-foreground">JD</div>
            <span className="font-display text-lg font-bold">JD <span className="gradient-text">Gadgets</span></span>
          </div>
          <p className="text-sm text-muted-foreground">
            Premium electronics, delivered. Curated gadgets from the world's best brands.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3">Shop</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/shop/$category" params={{ category: "mobiles" }} className="hover:text-foreground">Mobiles</Link></li>
            <li><Link to="/shop/$category" params={{ category: "laptops" }} className="hover:text-foreground">Laptops</Link></li>
            <li><Link to="/shop/$category" params={{ category: "desktops" }} className="hover:text-foreground">Desktops</Link></li>
            <li><Link to="/shop/$category" params={{ category: "tablets" }} className="hover:text-foreground">Tablets</Link></li>
            <li><Link to="/shop/$category" params={{ category: "ipads" }} className="hover:text-foreground">iPads</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3">Support</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Help Center</li>
            <li>Order Tracking</li>
            <li>Returns & Warranty</li>
            <li>Contact Us</li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3">Stay in the loop</h4>
          <p className="text-sm text-muted-foreground mb-3">Get launches and offers in your inbox.</p>
          <form className="flex gap-2">
            <input
              type="email"
              placeholder="you@email.com"
              className="flex-1 h-10 px-3 rounded-lg bg-secondary/60 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <button type="button" className="h-10 px-4 rounded-lg bg-gradient-primary text-primary-foreground text-sm font-semibold shadow-glow hover:opacity-90 transition-smooth">
              Join
            </button>
          </form>
        </div>
      </div>
      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} JD Gadgets. All rights reserved.
      </div>
    </footer>
  );
}

// JD Gadgets product catalog
import mobileImg from "@/assets/cat-mobiles.jpg";
import laptopImg from "@/assets/cat-laptops.jpg";
import desktopImg from "@/assets/cat-desktops.jpg";
import tabletImg from "@/assets/cat-tablets.jpg";
import ipadImg from "@/assets/cat-ipads.jpg";

export type Category = "mobiles" | "laptops" | "desktops" | "tablets" | "ipads";

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: Category;
  price: number;
  mrp: number;
  rating: number;
  reviews: number;
  image: string;
  storage?: string;
  ram?: string;
  highlights: string[];
  badge?: string;
}

const imageFor = (cat: Category) => {
  switch (cat) {
    case "mobiles": return mobileImg;
    case "laptops": return laptopImg;
    case "desktops": return desktopImg;
    case "tablets": return tabletImg;
    case "ipads": return ipadImg;
  }
};

const make = (
  id: string,
  name: string,
  brand: string,
  category: Category,
  price: number,
  mrp: number,
  rating: number,
  reviews: number,
  storage: string,
  ram: string,
  highlights: string[],
  badge?: string,
): Product => ({
  id, name, brand, category, price, mrp, rating, reviews, storage, ram, highlights, badge,
  image: imageFor(category),
});

export const products: Product[] = [
  // ===== MOBILES =====
  make("m1", "iPhone 15 Pro Max", "Apple", "mobiles", 134900, 159900, 4.8, 12450, "256GB", "8GB", ["A17 Pro", "Titanium", "48MP Pro"], "Bestseller"),
  make("m2", "iPhone 15 Pro", "Apple", "mobiles", 119900, 134900, 4.8, 9320, "128GB", "8GB", ["A17 Pro", "Titanium", "ProMotion"]),
  make("m3", "iPhone 15", "Apple", "mobiles", 79900, 89900, 4.7, 18200, "128GB", "6GB", ["A16 Bionic", "Dynamic Island"]),
  make("m4", "iPhone 14", "Apple", "mobiles", 67900, 79900, 4.7, 22340, "128GB", "6GB", ["A15 Bionic", "Ceramic Shield"]),
  make("m5", "iPhone 13", "Apple", "mobiles", 52900, 69900, 4.6, 31200, "128GB", "4GB", ["A15 Bionic", "Super Retina XDR"], "Deal"),
  make("m6", "Galaxy S24 Ultra", "Samsung", "mobiles", 129999, 149999, 4.7, 8410, "256GB", "12GB", ["S Pen", "200MP", "Snapdragon 8 Gen 3"], "New"),
  make("m7", "Galaxy S24+", "Samsung", "mobiles", 99999, 119999, 4.6, 5230, "256GB", "12GB", ["AMOLED 2X", "Snapdragon 8 Gen 3"]),
  make("m8", "Galaxy S24", "Samsung", "mobiles", 74999, 89999, 4.6, 6720, "128GB", "8GB", ["Galaxy AI", "120Hz"]),
  make("m9", "Galaxy Z Fold 5", "Samsung", "mobiles", 154999, 174999, 4.5, 2120, "256GB", "12GB", ["Foldable", "S Pen"]),
  make("m10", "Galaxy Z Flip 5", "Samsung", "mobiles", 99999, 109999, 4.5, 3450, "256GB", "8GB", ["Flex Window", "Foldable"]),
  make("m11", "Galaxy A55 5G", "Samsung", "mobiles", 39999, 45999, 4.4, 4210, "128GB", "8GB", ["sAMOLED", "5000mAh"]),
  make("m12", "iQOO 12", "iQOO", "mobiles", 52999, 59999, 4.5, 3120, "256GB", "12GB", ["Snapdragon 8 Gen 3", "144Hz"], "Hot"),
  make("m13", "iQOO Neo 9 Pro", "iQOO", "mobiles", 35999, 42999, 4.5, 5640, "256GB", "12GB", ["Snapdragon 8 Gen 2", "120W charge"]),
  make("m14", "iQOO Z9 5G", "iQOO", "mobiles", 19999, 24999, 4.3, 8210, "128GB", "8GB", ["Dimensity 7200", "AMOLED"]),
  make("m15", "OnePlus 12", "OnePlus", "mobiles", 64999, 69999, 4.6, 6720, "256GB", "12GB", ["Snapdragon 8 Gen 3", "Hasselblad"], "New"),
  make("m16", "OnePlus 12R", "OnePlus", "mobiles", 39999, 45999, 4.5, 4310, "128GB", "8GB", ["Snapdragon 8 Gen 2", "100W"]),
  make("m17", "OnePlus Nord 4", "OnePlus", "mobiles", 29999, 34999, 4.4, 2840, "128GB", "8GB", ["Snapdragon 7+ Gen 3"]),
  make("m18", "Xiaomi 14", "Xiaomi", "mobiles", 69999, 79999, 4.5, 3420, "256GB", "12GB", ["Leica", "Snapdragon 8 Gen 3"]),
  make("m19", "Redmi Note 13 Pro+", "Xiaomi", "mobiles", 29999, 34999, 4.4, 9120, "256GB", "8GB", ["200MP", "AMOLED 1.5K"]),
  make("m20", "Redmi Note 13", "Xiaomi", "mobiles", 17999, 21999, 4.3, 12340, "128GB", "6GB", ["AMOLED", "Snapdragon"]),
  make("m21", "POCO X6 Pro", "POCO", "mobiles", 26999, 32999, 4.4, 6210, "256GB", "8GB", ["Dimensity 8300", "120Hz"], "Deal"),
  make("m22", "Realme GT 6", "Realme", "mobiles", 40999, 48999, 4.4, 2120, "256GB", "8GB", ["Snapdragon 8s Gen 3"]),
  make("m23", "Vivo X100 Pro", "Vivo", "mobiles", 89999, 99999, 4.6, 1820, "512GB", "16GB", ["Zeiss", "Dimensity 9300"]),
  make("m24", "Pixel 8 Pro", "Google", "mobiles", 106999, 113999, 4.6, 2310, "256GB", "12GB", ["Tensor G3", "Magic Editor"]),
  make("m25", "Pixel 8", "Google", "mobiles", 75999, 82999, 4.6, 4120, "128GB", "8GB", ["Tensor G3", "AI camera"]),
  make("m26", "Nothing Phone (2)", "Nothing", "mobiles", 39999, 44999, 4.4, 5210, "256GB", "12GB", ["Glyph Interface", "OLED"]),
  make("m27", "Motorola Edge 50 Pro", "Motorola", "mobiles", 31999, 35999, 4.3, 1820, "256GB", "8GB", ["pOLED", "125W"]),
  make("m28", "Asus ROG Phone 8 Pro", "Asus", "mobiles", 99999, 109999, 4.5, 1240, "512GB", "16GB", ["Gaming", "165Hz"]),

  // ===== LAPTOPS =====
  make("l1", "MacBook Pro 16\" M3 Max", "Apple", "laptops", 349900, 399900, 4.9, 3420, "1TB SSD", "36GB", ["M3 Max", "Liquid Retina XDR"], "Pro"),
  make("l2", "MacBook Pro 14\" M3 Pro", "Apple", "laptops", 199900, 229900, 4.9, 5210, "512GB SSD", "18GB", ["M3 Pro", "ProMotion"]),
  make("l3", "MacBook Air 15\" M3", "Apple", "laptops", 134900, 149900, 4.8, 6320, "256GB SSD", "8GB", ["M3 chip", "Liquid Retina"], "New"),
  make("l4", "MacBook Air 13\" M3", "Apple", "laptops", 114900, 129900, 4.8, 8420, "256GB SSD", "8GB", ["M3 chip", "Fanless"], "Bestseller"),
  make("l5", "MacBook Air 13\" M2", "Apple", "laptops", 99900, 119900, 4.8, 12340, "256GB SSD", "8GB", ["M2 chip", "Retina"]),
  make("l6", "Galaxy Book4 Ultra", "Samsung", "laptops", 259999, 289999, 4.6, 820, "1TB SSD", "32GB", ["Core Ultra 9", "RTX 4070"]),
  make("l7", "Galaxy Book4 Pro", "Samsung", "laptops", 149999, 169999, 4.5, 1240, "512GB SSD", "16GB", ["Core Ultra 7", "AMOLED"]),
  make("l8", "Galaxy Book4", "Samsung", "laptops", 89999, 99999, 4.4, 2120, "512GB SSD", "16GB", ["Core 7", "FHD"]),
  make("l9", "Dell XPS 15", "Dell", "laptops", 184999, 219999, 4.7, 3420, "1TB SSD", "32GB", ["Core i9", "RTX 4060", "OLED"]),
  make("l10", "Dell XPS 13", "Dell", "laptops", 119999, 139999, 4.6, 4120, "512GB SSD", "16GB", ["Core i7", "InfinityEdge"]),
  make("l11", "Dell Inspiron 15", "Dell", "laptops", 54999, 64999, 4.3, 6210, "512GB SSD", "16GB", ["Core i5", "FHD+"], "Deal"),
  make("l12", "HP Spectre x360", "HP", "laptops", 154999, 174999, 4.6, 2120, "1TB SSD", "16GB", ["2-in-1", "OLED touch"]),
  make("l13", "HP Pavilion 14", "HP", "laptops", 64999, 74999, 4.3, 5230, "512GB SSD", "16GB", ["Core i5", "FHD"]),
  make("l14", "HP Omen 16", "HP", "laptops", 134999, 154999, 4.5, 1820, "1TB SSD", "16GB", ["RTX 4060", "165Hz"]),
  make("l15", "Lenovo ThinkPad X1 Carbon", "Lenovo", "laptops", 169999, 199999, 4.7, 2240, "1TB SSD", "16GB", ["Core i7", "Carbon fiber"]),
  make("l16", "Lenovo Legion 7i", "Lenovo", "laptops", 199999, 229999, 4.6, 1620, "1TB SSD", "32GB", ["RTX 4070", "240Hz"]),
  make("l17", "Lenovo IdeaPad Slim 5", "Lenovo", "laptops", 59999, 69999, 4.3, 4120, "512GB SSD", "16GB", ["Ryzen 7", "OLED"]),
  make("l18", "Asus ROG Zephyrus G14", "Asus", "laptops", 174999, 199999, 4.7, 2840, "1TB SSD", "16GB", ["RTX 4060", "QHD 165Hz"], "Gamer"),
  make("l19", "Asus ZenBook 14 OLED", "Asus", "laptops", 89999, 99999, 4.5, 3210, "512GB SSD", "16GB", ["OLED", "Core Ultra 7"]),
  make("l20", "Asus TUF Gaming A15", "Asus", "laptops", 79999, 94999, 4.4, 4120, "512GB SSD", "16GB", ["Ryzen 7", "RTX 4050"]),
  make("l21", "Acer Predator Helios 16", "Acer", "laptops", 184999, 209999, 4.5, 1240, "1TB SSD", "16GB", ["RTX 4070", "240Hz Mini-LED"]),
  make("l22", "Acer Swift Go 14", "Acer", "laptops", 79999, 89999, 4.3, 1820, "512GB SSD", "16GB", ["Core Ultra 5", "OLED"]),
  make("l23", "MSI Stealth 16 AI", "MSI", "laptops", 199999, 229999, 4.5, 920, "1TB SSD", "32GB", ["Core Ultra 9", "RTX 4070"]),
  make("l24", "Razer Blade 15", "Razer", "laptops", 224999, 259999, 4.6, 720, "1TB SSD", "16GB", ["RTX 4070", "QHD 240Hz"]),
  make("l25", "Microsoft Surface Laptop 5", "Microsoft", "laptops", 109999, 129999, 4.5, 2120, "512GB SSD", "16GB", ["PixelSense", "Core i7"]),

  // ===== DESKTOPS =====
  make("d1", "iMac 24\" M3", "Apple", "desktops", 134900, 154900, 4.8, 2120, "256GB SSD", "8GB", ["4.5K Retina", "M3 chip"], "New"),
  make("d2", "Mac Studio M2 Ultra", "Apple", "desktops", 339900, 379900, 4.9, 820, "1TB SSD", "64GB", ["M2 Ultra", "Pro power"], "Pro"),
  make("d3", "Mac mini M2 Pro", "Apple", "desktops", 124900, 139900, 4.8, 3120, "512GB SSD", "16GB", ["M2 Pro", "Compact"]),
  make("d4", "Mac mini M2", "Apple", "desktops", 59900, 69900, 4.8, 5420, "256GB SSD", "8GB", ["M2 chip", "Tiny powerhouse"], "Bestseller"),
  make("d5", "HP OMEN 45L Gaming", "HP", "desktops", 219999, 249999, 4.6, 1240, "1TB SSD", "32GB", ["RTX 4070 Ti", "Core i7"]),
  make("d6", "HP Pavilion Desktop", "HP", "desktops", 64999, 74999, 4.3, 2840, "512GB SSD", "16GB", ["Core i5", "Compact"]),
  make("d7", "Dell XPS Desktop", "Dell", "desktops", 134999, 154999, 4.5, 1620, "1TB SSD", "16GB", ["Core i7", "RTX 4060"]),
  make("d8", "Dell Alienware Aurora R16", "Dell", "desktops", 269999, 299999, 4.6, 920, "2TB SSD", "32GB", ["RTX 4080", "Liquid cool"], "Gamer"),
  make("d9", "Lenovo Legion Tower 7i", "Lenovo", "desktops", 229999, 259999, 4.5, 720, "1TB SSD", "32GB", ["RTX 4070 Ti", "Core i9"]),
  make("d10", "Lenovo IdeaCentre 5", "Lenovo", "desktops", 54999, 64999, 4.2, 1820, "512GB SSD", "16GB", ["Ryzen 5", "Compact"], "Deal"),
  make("d11", "Asus ROG Strix G35", "Asus", "desktops", 209999, 239999, 4.5, 620, "1TB SSD", "32GB", ["RTX 4070", "Core i7"]),
  make("d12", "MSI Aegis RS", "MSI", "desktops", 224999, 254999, 4.5, 540, "1TB SSD", "32GB", ["RTX 4070 Ti", "RGB"]),
  make("d13", "Acer Predator Orion 7000", "Acer", "desktops", 259999, 289999, 4.5, 480, "2TB SSD", "32GB", ["RTX 4080", "Core i9"]),
  make("d14", "Samsung All-in-One 27\"", "Samsung", "desktops", 79999, 89999, 4.3, 1240, "512GB SSD", "16GB", ["27\" FHD", "Slim AIO"]),
  make("d15", "Corsair Vengeance i7400", "Corsair", "desktops", 239999, 269999, 4.6, 320, "2TB SSD", "32GB", ["RTX 4070 Ti", "Custom build"]),

  // ===== TABLETS =====
  make("t1", "Galaxy Tab S9 Ultra", "Samsung", "tablets", 108999, 124999, 4.7, 2120, "256GB", "12GB", ["14.6\" AMOLED", "S Pen"], "Pro"),
  make("t2", "Galaxy Tab S9+", "Samsung", "tablets", 84999, 99999, 4.6, 1820, "256GB", "12GB", ["12.4\" AMOLED", "S Pen"]),
  make("t3", "Galaxy Tab S9", "Samsung", "tablets", 69999, 79999, 4.6, 2420, "128GB", "8GB", ["11\" AMOLED", "S Pen"]),
  make("t4", "Galaxy Tab S9 FE+", "Samsung", "tablets", 49999, 59999, 4.4, 1620, "128GB", "8GB", ["12.4\" LCD", "S Pen"]),
  make("t5", "Galaxy Tab A9+", "Samsung", "tablets", 19999, 24999, 4.3, 4120, "64GB", "4GB", ["11\" 90Hz", "Quad speakers"], "Deal"),
  make("t6", "OnePlus Pad", "OnePlus", "tablets", 37999, 42999, 4.5, 1820, "128GB", "8GB", ["11.6\" 144Hz", "Dimensity 9000"]),
  make("t7", "OnePlus Pad Go", "OnePlus", "tablets", 19999, 22999, 4.4, 2310, "128GB", "8GB", ["11.35\" LCD", "8000mAh"]),
  make("t8", "Xiaomi Pad 6", "Xiaomi", "tablets", 26999, 31999, 4.4, 3120, "128GB", "6GB", ["11\" 144Hz", "Snapdragon 870"]),
  make("t9", "Xiaomi Pad 6 Pro", "Xiaomi", "tablets", 39999, 45999, 4.5, 1820, "256GB", "8GB", ["11\" 144Hz", "Snapdragon 8+ Gen 1"]),
  make("t10", "Lenovo Tab P12 Pro", "Lenovo", "tablets", 44999, 52999, 4.4, 1240, "256GB", "8GB", ["12.7\" 3K", "Pen included"]),
  make("t11", "Lenovo Tab M11", "Lenovo", "tablets", 17999, 21999, 4.2, 2840, "128GB", "8GB", ["11\" 90Hz", "Pen included"]),
  make("t12", "Realme Pad 2", "Realme", "tablets", 19999, 24999, 4.3, 1820, "128GB", "8GB", ["11.5\" 120Hz", "Dimensity"]),
  make("t13", "Honor Pad 9", "Honor", "tablets", 23999, 28999, 4.4, 920, "256GB", "8GB", ["12.1\" 2.5K", "8 speakers"]),
  make("t14", "Microsoft Surface Pro 9", "Microsoft", "tablets", 109999, 129999, 4.6, 1620, "256GB", "16GB", ["13\" PixelSense", "Core i5"]),
  make("t15", "Microsoft Surface Go 4", "Microsoft", "tablets", 64999, 74999, 4.3, 720, "128GB", "8GB", ["10.5\" PixelSense"]),

  // ===== iPads =====
  make("i1", "iPad Pro 13\" M4", "Apple", "ipads", 119900, 129900, 4.9, 1820, "256GB", "8GB", ["M4 chip", "Tandem OLED", "Apple Pencil Pro"], "New"),
  make("i2", "iPad Pro 11\" M4", "Apple", "ipads", 99900, 109900, 4.9, 2120, "256GB", "8GB", ["M4 chip", "Ultra Retina XDR"]),
  make("i3", "iPad Air 13\" M2", "Apple", "ipads", 79900, 89900, 4.8, 1620, "128GB", "8GB", ["M2 chip", "Liquid Retina"], "Hot"),
  make("i4", "iPad Air 11\" M2", "Apple", "ipads", 59900, 69900, 4.8, 2840, "128GB", "8GB", ["M2 chip", "Apple Pencil Pro"]),
  make("i5", "iPad 10th Gen", "Apple", "ipads", 34900, 39900, 4.7, 5420, "64GB", "4GB", ["A14 Bionic", "10.9\" Liquid Retina"], "Bestseller"),
  make("i6", "iPad mini 6", "Apple", "ipads", 46900, 52900, 4.7, 4120, "64GB", "4GB", ["A15 Bionic", "8.3\" Liquid Retina"]),
  make("i7", "iPad 9th Gen", "Apple", "ipads", 29900, 34900, 4.6, 8120, "64GB", "3GB", ["A13 Bionic", "10.2\" Retina"], "Deal"),
  make("i8", "iPad Pro 12.9\" M2", "Apple", "ipads", 109900, 119900, 4.9, 3210, "128GB", "8GB", ["M2 chip", "Mini-LED"]),
  make("i9", "iPad Pro 11\" M2", "Apple", "ipads", 81900, 89900, 4.9, 2820, "128GB", "8GB", ["M2 chip", "ProMotion"]),
];

export const categories = [
  { id: "mobiles" as const, name: "Mobiles", image: mobileImg, count: products.filter(p => p.category === "mobiles").length },
  { id: "laptops" as const, name: "Laptops", image: laptopImg, count: products.filter(p => p.category === "laptops").length },
  { id: "desktops" as const, name: "Desktops", image: desktopImg, count: products.filter(p => p.category === "desktops").length },
  { id: "tablets" as const, name: "Tablets", image: tabletImg, count: products.filter(p => p.category === "tablets").length },
  { id: "ipads" as const, name: "iPads", image: ipadImg, count: products.filter(p => p.category === "ipads").length },
];

export const brands = Array.from(new Set(products.map(p => p.brand))).sort();

export const getProduct = (id: string) => products.find(p => p.id === id);
export const getByCategory = (cat: Category) => products.filter(p => p.category === cat);
